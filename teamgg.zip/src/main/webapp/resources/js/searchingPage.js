$(document).ready(function() {
    
    const qtsb = $('.queue_type_select_button');
    const total =$('#total');
    const soloRank =$('#soloRank');
    const normalGame =$('#normalGame');

    
    const divAllLi = $('div.queue_content');
    //const liElements = divAllLi.querySelectorAll('>li');
    const liElements = document.querySelectorAll('div.queue_content > li');
    
    $('.addInfoBtn').click(function() {
      // 클릭된 버튼의 부모 div에서 데이터를 가져옵니다.
      var $div = $(this).closest('.addBtnDiv');
      var $parents = $div.parent().parent();
      // 예: 해당 div의 배경색을 변경합니다.
     // $div.children('add_info').css('display', 'block');
     $parents.find('.addInfo').toggleClass('hidden');
      $(this).toggleClass('rotated');
     
  });

    //경기 버튼 색깔 입히기
    total.on('click', function(){
        console.log('버튼 클릭함');
          soloRank.removeClass('selected');
          normalGame.removeClass('selected');
           $(this).addClass('selected');
        
          for(let i = 0; i < liElements.length ; i++){
            var li = liElements[i];
            li.style.display = 'block';
          }

    })

    soloRank.on('click', function(){
      console.log('버튼 클릭함');
        total.removeClass('selected');
        normalGame.removeClass('selected');
      $(this).addClass('selected');

        //코드를 추가하게 만들기

        for(let i = 0; i < liElements.length ; i++){
          var li = liElements[i];
          var gameTypeDiv = li.querySelector('.gameType').textContent;
          if(gameTypeDiv != "솔랭"){
            li.style.display = 'none';
        } else {
          li.style.display = 'block';
        }
        }
    })

        normalGame.on('click', function(){
          console.log('버튼 클릭함');
            soloRank.removeClass('selected');
            total.removeClass('selected');
            $(this).addClass('selected');
        
            for(let i = 0; i < liElements.length ; i++){
              var li = liElements[i];
              var gameTypeDiv = li.querySelector('.gameType').textContent;
              if(gameTypeDiv == "솔랭"){
                li.style.display = 'none';
            } else {
              li.style.display = 'block';
            }
            }
    })

    $("#cat2").click(function() {				
      $.ajax({					
        url: "/teamgg/searchapi/addInfo",				
        method: "GET",				
        data: {"a":"야옹"},				
        success: function(response) {				
          $("#cat2_area").text("이름:" + response.name + " 나이:" + response.age);			
        },				
        error: function(xhr, status, error) {				
          console.error(error);			
        }				
      });								
    });	

   
  
    
    
  });