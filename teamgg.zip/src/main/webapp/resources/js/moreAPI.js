$(function() {					
	var xhr = new XMLHttpRequest();				
			
	//$("#cat2").on("click", function() {				
        $("#callAPI").click(function() {				
            $.ajax({					
                url: "/teamgg/searchapi/addInfo",				
                method: "GET",				
                success: function(response) {
                    var adi = $('.addedInfo');
                    // var $div = $(this).closest('.more_info');
                    // var $parent = $div.parent().find('div.queue_content .addedInfo');
                    
                    $("#cat2_area").text("이름:" + response.name + " 나이:" + response.age);			
                },				
                error: function(xhr, status, error) {				
                    console.error(error);			
                }				
            });								
        });	
					
//	} 대신				
});	// 이렇게 마무리 해야되는거 주의.				