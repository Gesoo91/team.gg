function goBack() {
    window.history.back();
}

function submitForm() {
    document.getElementById('form').submit();
}