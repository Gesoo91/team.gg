$(document).ready(function(){
    $('#toggleBest').click(function(){
        $('#toggleBox').slideToggle('fast');
        var toggleText = toggleBest.textContent;
        if (toggleText === '▲') {
            toggleBest.textContent = '▼';
        } else {
            toggleBest.textContent = '▲';
        }
    });

    $('#search-btn').click(function() {
        var option = $('.search-option').val(); // 선택된 검색 옵션
        var keyword = $('#search-input').val(); // 검색어
        
        $.ajax({
            type: 'GET', // 또는 POST - 컨트롤러의 HTTP 메소드와 일치해야 합니다
            url: '/freeList', // 검색을 처리하는 컨트롤러의 URL
            data: {
                option: option,
                keyword: keyword
            },
            success: function(response) {
                // 성공 시 수행할 작업 (예: 검색 결과를 화면에 표시)
                $('#postBox').html(response); // 검색 결과를 postBox 영역에 출력
            },
            error: function(error) {
                // 에러 시 수행할 작업
            }
        });
    });
});