				// 수정, 삭제 버튼 처리(글)
				document.addEventListener("DOMContentLoaded", function () {
					var readActionDiv = document.querySelector(".read_action");		    
						if (userId === tId) {
									readActionDiv.style.display = 'block';
								} else {
									readActionDiv.style.display = 'none';
								}
							});	

				// 글 삭제 팝업
				document.getElementById('read_delete').addEventListener('click', function () {
					var tIdx = this.getAttribute('data-t-idx');
					if (confirm("삭제하시겠습니까?")) {
						location.href = 'tipDel?t_idx=' + tIdx;
					} else {
						window.close();
					}
				});

				// 추천수 불러오기
				$(document).ready(function() {
					function updateVoteCount() {
						$.ajax({
							type: "GET",
							url: "/teamgg/board/getVoteCountTip",
							data: {
								t_idx: tIdx
							},
							success: function(data) {
								var voteCount = data.voteCount;
								$('.voteCount').text(voteCount);
							},
							error: function(xhr, status, error) {
								console.error('getV실패');
							}
						});
					}
					
					// 추천, 취소 버튼 설정
					  // 페이지 로드 시 초기화
					  updateVoteCount()
					  $('#upVoteBtn').hide();
					  $('#downVoteBtn').hide();
					// Ajax 호출
					  if (currentUserId !== "null") {
						  $.ajax({
							  type: "GET",
							  url: "/teamgg/board/checkVoteTip",
							  data: {
								  t_idx: tIdx
							  },
							  success: function(count) {
								  if (count === '0') {
									  $('#upVoteBtn').show();
								  } else if (count === '1') {
									  $('#downVoteBtn').show();
								  }
							  },
							  error: function(xhr, status, error) {
								  console.error('버튼노출에러');
							  }
						  });
					  } else {
						  $('#upVoteBtn').show();
					  }
					  
					  // 클릭 이벤트 핸들러
					$('#upVoteBtn, #downVoteBtn').on('click', function() {
						if (currentUserId === "null") {
							alert('로그인이 필요합니다.');
							window.location.href = '/teamgg/member/login';
							return;
						}

						if (currentUserId === tId) {
							alert('자신의 글에 추천할 수 없습니다.');
							return;
						}
						
						$.ajax({
							type: 'POST',
							url: '/teamgg/board/updateVoteTip', // 컨트롤러에 매핑된 URL
							data: { m_id: currentUserId, t_idx: tIdx },
							success: function (response) {
								// 성공 시 처리할 로직
								if ($('#upVoteBtn').is(':visible')) {
									$('#upVoteBtn').hide();
									$('#downVoteBtn').show();
								} else {
									$('#downVoteBtn').hide();
									$('#upVoteBtn').show();
								}
									updateVoteCount();
							},
							error: function (error) {
								console.error('추천 취소/실패');
							}
						});
					});
				});
                            
				// 답글 버튼
                var replyButtons = document.querySelectorAll('.replyForm-btn');
                replyButtons.forEach(function (button) {
                    button.addEventListener('click', function () {
                        var replyContainer = this.parentElement;
                        var replyForm = replyContainer.querySelector('.replyForm');
                        var replyList = replyContainer.querySelector('.replyList');
                        replyForm.classList.toggle('hidden');
                        replyList.classList.toggle('hidden');
                    });
                });		
               
				// 수정, 삭제 버튼 처리(댓글)
				var modifyButtons = document.querySelectorAll('.replyForm-modify');
				var deleteButtons = document.querySelectorAll('.replyForm-delete');
				var replyButtons = document.querySelectorAll('.replyForm-btn');

				modifyButtons.forEach(function (button) {
					var tcId = button.getAttribute('data-tc-id');
					if (tcId !== currentUserId) {
						button.style.display = 'none';
					}
				});
				deleteButtons.forEach(function (button) {
					var tcId = button.getAttribute('data-tc-id');
					if (tcId !== currentUserId) {
						button.style.display = 'none';
					}
				});	

				// 답글 버튼 스타일 변경
				replyButtons.forEach(function (button) {
					var tcId = button.getAttribute('data-tc-id');
					if (tcId !== currentUserId) {
						button.style.marginLeft = '30px'; // 현재 로그인된 사용자와 작성자 ID가 다를 때 왼쪽 여백 추가
					}
				});	

                	             // 수정 버튼 클릭 시 모달 열기
	             var modifyButtons = document.querySelectorAll('.replyForm-modify');
	             modifyButtons.forEach(function (button) {
	                 button.addEventListener('click', function () {
	                 	// 버튼에서 tc_idx 값 꺼내옴
	                     var editTcIdx = this.getAttribute('data-tc-idx');
	                     var writerId = this.getAttribute('data-tc-id');
						 var tcComment = this.getAttribute('data-tc-comment'); // 원댓 내용 설정
	                     var modal = document.getElementById('commentModal');
	                     var modalContent = modal.querySelector('.modal-content');
	                     var tcIdxInput = modalContent.querySelector('input[name="tc_idx"]');
	                     // 꺼내온 tc_idx 값 설정
	                     tcIdxInput.value = editTcIdx;
						// 원댓 내용 설정
						var tcCommentInput = modalContent.querySelector('textarea[name="tc_comment"]');
						tcCommentInput.value = tcComment;
	             if (isLoggedIn && currentUserId === writerId) {
	                 // 로그인된 상태에서만 모달 열기
	                 modal.style.display = 'block';
	                 console.log('editTcIdx:', editTcIdx);
	                 console.log('tcIdxInput:', tcIdxInput);
	                 console.log('writerId:', writerId);
	             } else {
	                 // 비로그인 상태에서는 페이지 이동
	                 window.location.href = '/teamgg/member/login';
	             }
	                 });
	             });			

	             // 취소버튼으로 모달 닫기
	             var cancelEditButton = document.querySelector('#modifyForm-cancel');
	             cancelEditButton.addEventListener('click', function () {
	                 var modal = document.getElementById('commentModal');
	                 modal.style.display = 'none';
            	});

				// 댓글 삭제 팝업
				document.querySelectorAll('.replyForm-delete').forEach(function (element) {
					element.addEventListener('click', function () {
						var tcIdx = this.getAttribute('data-tc-idx');
						if (confirm("삭제하시겠습니까?")) {
							location.href = '/teamgg/comment/tcDel?tc_idx=' + tcIdx;
						} else {
							window.close();
						}
					});
				});