
package com.peisia.spring.spb.lol;


public class BasisicLoginVo {

    public String id;
    public String accountId;
    public String puuid;
    public String name;
    public Integer profileIconId;
    public Long revisionDate;
    public Integer summonerLevel;

}
