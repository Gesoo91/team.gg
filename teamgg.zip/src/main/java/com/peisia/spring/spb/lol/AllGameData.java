package com.peisia.spring.spb.lol;

import java.util.ArrayList;
import java.util.Map;

import lombok.Data;

@Data
public class AllGameData {
	public ArrayList<Lol_api> xx;
	public Map<String, GradeInfo> cg;
	public GradeInfo mg;
	public Map<String, Positions> positions;
	public Integer mainKills = 0;
	public Integer mainAsis = 0;
	public Integer mainDeaths = 0;
	public Integer totalkills = 0;
	public Integer utotalkills = 0;
	public int rankGames = 0;
	public int endNum = 0;

	
	
	public AllGameData(ArrayList<Lol_api> xx, Map<String, GradeInfo> cg, GradeInfo mg,
			Map<String, Positions> positions, Integer mainKills, Integer mainAsis, Integer mainDeaths,
			Integer totalkills, Integer utotalkills, int rankGames, int endNum) {
		this.xx = xx;
		this.cg = cg;
		this.mg = mg;
		this.positions = positions;
		this.mainKills = mainKills;
		this.mainAsis = mainAsis;
		this.mainDeaths = mainDeaths;
		this.totalkills = totalkills;
		this.utotalkills = utotalkills;
		this.rankGames = rankGames;
		this.endNum = endNum;
	}

}
