package com.teamproject.spring.teamgg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.peisia.spring.spb.lol.AllGameData;
import com.peisia.spring.spb.lol.Lol_api;
import com.peisia.spring.spb.lol.Summoner;
import com.teamproject.spring.teamgg.api.Api_and_Etc;

import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/searchapi/*")
@RestController
public class MoreApiController {
	
	@GetMapping("/addInfo")	
	public ArrayList<Lol_api> getCatOne(HttpServletRequest request) {	
		log.info("====================api 컨트롤러 한번 지나감");
		ArrayList<Lol_api> xx = new ArrayList<Lol_api>();
		Api_and_Etc aae = new Api_and_Etc();
		HttpSession session = request.getSession();
		Summoner temp = (Summoner) session.getAttribute("temp");
		log.info("=======temp 값 받았나? : " + temp.getName());
		String region = (String) session.getAttribute("region");
		log.info("=======지역 값 받았나? : " + region);
		int startNum = (int) session.getAttribute("nextNum");
		log.info("=======다음 스타트 값 받았나? : " + startNum);
		int endNum = startNum+9;
		session.setAttribute("nextNum", endNum+1);
		List<String> grbc = aae.getMatchList(region, temp.getPuuid(), startNum, endNum);
		log.info("=======1번째 경기id 값 받았나? : " + aae);
		AllGameData gd = aae.getMatchInfo(grbc, region, endNum, temp);
		xx = gd.getXx();
		log.info("=======xx 값 받았나? : " + xx.get(1).mainUser.summonerName);
		return xx;
	}	
}
