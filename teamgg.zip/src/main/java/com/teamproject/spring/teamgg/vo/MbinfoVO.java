package com.teamproject.spring.teamgg.vo;

import lombok.Data;

@Data
public class MbinfoVO {
	private String m_id ;
	private String m_user ;
	private String m_pw ;
	private String m_email ;
	private String m_date ;
	private String m_role;
}
