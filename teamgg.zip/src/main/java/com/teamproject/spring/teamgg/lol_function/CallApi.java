package com.teamproject.spring.teamgg.lol_function;

public class CallApi {

	
}
