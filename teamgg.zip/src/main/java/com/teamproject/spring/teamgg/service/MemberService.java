package com.teamproject.spring.teamgg.service;

import java.util.List;

import javax.servlet.http.HttpSession;

import com.teamproject.spring.teamgg.vo.MemberVO;

public interface MemberService {
	// 회원가입
	public void register(MemberVO mvo);

	// 아이디중복체크
	public int idchk(MemberVO mvo);

	// 닉네임중복체크
	public int userchk(MemberVO mvo);

	// 로그인
	public MemberVO login(MemberVO mvo);

	// 로그아웃
	public void logout(HttpSession session);

	// 회원리스트
	public List<MemberVO> memberlist();

	// 회원정보
	public List<MemberVO> memberdetail(String id);

	// 회원탈퇴
	public void memberdelete(String id);
}
