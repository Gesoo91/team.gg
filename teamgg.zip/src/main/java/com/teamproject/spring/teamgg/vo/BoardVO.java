package com.teamproject.spring.teamgg.vo;

import java.util.Date;

import com.teamproject.spring.teamgg.board.TimeFormatter;

import lombok.Data;


@Data
public class BoardVO {
	private Long writeIdx;
	private Long b_idx;
	private String board_type;
	private String user;
	private String title;
	private String date;
	private Long view;
	private Long vote;
	
	public void setDate(Date date) {
		this.date = TimeFormatter.calculateTime(date);
	}
	
//	FreeBoard
	public final static String TABLE_NAME_FREE = "free_board";
	private Long f_idx;
	private String f_title;
	private String f_id;
	private String f_user;
	private String f_content;
	private String f_date;
	private Long f_view;
	private Long f_vote;

	public void setF_date(Date f_date) {
		this.f_date = TimeFormatter.calculateTime(f_date);
	}
	
//	TipBoard
	public final static String TABLE_NAME_TIP = "tip_board";
	private Long t_idx;
	private String t_title;
	private String t_id;
	private String t_user;
	private String t_content;
	private String t_date;
	private Long t_view;
	private Long t_vote;

	public void setT_date(Date t_date) {
		this.t_date = TimeFormatter.calculateTime(t_date);
	}
	
//	CompBoard
	public final static String TABLE_NAME_COMP = "comp_board";
	private Long c_idx;
	private String c_title;
	private String c_id;
	private String c_user;
	private String c_content;
	private String c_date;
	private Long c_view;
	private Long c_vote;

	public void setC_date(Date c_date) {
		this.c_date = TimeFormatter.calculateTime(c_date);
	}
}