package com.teamproject.spring.teamgg.service;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.annotations.Param;

import com.teamproject.spring.teamgg.vo.BoardVO;

public interface BoardService {
	
	public int getStartIndex(int page);
	public List<BoardVO> getBestList();
	
//	FreeBoard
	public List<BoardVO> getFreeList(int index);
	public int getTotalCountFree();
	public int getTotalPageFree();
	public int getTotalBlockFree(int totalPage);
	public BoardVO freeRead(long f_idx);
	public void freeDel(long f_idx);
	public void freeWrite(BoardVO vo);
	public void freeModify(BoardVO vo);
	public void updateViewCountFree(Long f_idx);
	void setViewCountFree(Long f_idx, HttpServletRequest request, HttpServletResponse response);
	public int getVoteCountFree(int f_idx);
	public void upVoteCountFree(Long f_idx);
	public void downVoteCountFree(Long f_idx);
    public int checkVoteFree(@Param("m_id") String m_id, @Param("f_idx") Long f_idx);
    public void updateVoteFree(@Param("m_id") String m_id, @Param("f_idx") Long f_idx);
    public void cancelVoteFree(@Param("m_id") String m_id, @Param("f_idx") Long f_idx);
    public List<BoardVO> searchPosts(int index, String option, String keyword);
	
//	TipBoard
	public List<BoardVO> getTipList(int index);
	public BoardVO tipRead(long t_idx);
	public int getTotalCountTip();
	public int getTotalPageTip();
	public int getTotalBlockTip(int totalPage);
	public void tipDel(long t_idx);
	public void tipWrite(BoardVO vo);
	public void tipModify(BoardVO vo);
	public void updateViewCountTip(Long t_idx);
	void setViewCountTip(Long t_idx, HttpServletRequest request, HttpServletResponse response);
	public int getVoteCountTip(int t_idx);
	public void upVoteCountTip(Long t_idx);
	public void downVoteCountTip(Long t_idx);
    public int checkVoteTip(@Param("m_id") String m_id, @Param("t_idx") Long t_idx);
    public void updateVoteTip(@Param("m_id") String m_id, @Param("t_idx") Long t_idx);
    public void cancelVoteTip(@Param("m_id") String m_id, @Param("t_idx") Long t_idx);
	
//	CompBoard
	public List<BoardVO> getCompList(int index);
	public BoardVO compRead(long c_idx);
	public int getTotalCountComp();
	public int getTotalPageComp();
	public int getTotalBlockComp(int totalPage);
	public void compDel(long c_idx);
	public void compWrite(BoardVO vo);
	public void compModify(BoardVO vo);
	public void updateViewCountComp(Long c_idx);
	void setViewCountComp(Long c_idx, HttpServletRequest request, HttpServletResponse response);
	public int getVoteCountComp(int c_idx);
	public void upVoteCountComp(Long c_idx);
	public void downVoteCountComp(Long c_idx);
    public int checkVoteComp(@Param("m_id") String m_id, @Param("c_idx") Long c_idx);
    public void updateVoteComp(@Param("m_id") String m_id, @Param("c_idx") Long c_idx);
    public void cancelVoteComp(@Param("m_id") String m_id, @Param("c_idx") Long c_idx);
}
