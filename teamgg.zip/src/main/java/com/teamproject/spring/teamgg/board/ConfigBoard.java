package com.teamproject.spring.teamgg.board;

public class ConfigBoard {
	static public int AMOUNT_PER_PAGE = 20;
	static public int PAGE_PER_BLOCK = 3;
}
