package com.teamproject.spring.teamgg.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.peisia.spring.spb.lol.AllGameData;
import com.peisia.spring.spb.lol.GameInfo;
import com.peisia.spring.spb.lol.GradeInfo;
import com.peisia.spring.spb.lol.LoginInfoVo;
import com.peisia.spring.spb.lol.Lol_api;
import com.peisia.spring.spb.lol.Positions;
import com.peisia.spring.spb.lol.Summoner;
import com.teamproject.spring.teamgg.api.Api_and_Etc;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/search/*")
@AllArgsConstructor
@Controller
public class SearchController {

	@RequestMapping("/exist_user")
	public String exist_user(@RequestParam("userName") String userName, @RequestParam("region") String region,
			HttpServletRequest request, Model model) throws UnsupportedEncodingException {
		Api_and_Etc aae = new Api_and_Etc();
		String SummonerName = userName.replaceAll(" ", "%20");
		HttpSession session = request.getSession();
		session.setAttribute("region", region);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		Summoner temp = null;
		temp = aae.getSummonerInfo(SummonerName, region);//유저 정보 호출
		if (temp == null) {
			String result = "none";
			return "redirect:/search/no_search?result=" + result;
		}
		String utrName = URLEncoder.encode(SummonerName, "UTF-8");
		SummonerName = utrName.replaceAll("%25", "%");
		System.out.println("다음으로 넘어가는 이름은? : " + SummonerName);
		session.setAttribute("temp", temp);
		model.addAttribute("temp", temp);
		return "redirect:/search/searching_player?userName=" + SummonerName + "&region=" + region;

	}

	@RequestMapping("/no_search")
	public void no_search() {
		System.out.println("한번 지나감 ");
	}

	@RequestMapping("/searching_player")
	public void searching_player(@RequestParam("userName") String userName, @RequestParam("region") String region,
			HttpServletRequest request, Model model) {
		//// 우리나라 공공 api ////
		// 인코딩 인증키
		Api_and_Etc aae = new Api_and_Etc();//api코드 호출 전용 클래스
		// 세션에서 값 불러오기
		HttpSession session = request.getSession();
		Summoner temp = (Summoner) session.getAttribute("temp");

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		// 새로 고침 할 때
		if (temp == null) {
			String SummonerName = userName.replaceAll(" ", "%20");//UTF 처리된 코드 쓸수 있게 원상 복구
			temp = aae.getSummonerInfo(SummonerName, region);
		}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		LoginInfoVo LoginInfoVo = null;
		LoginInfoVo = aae.getLeagueInfo(region, temp.getId());//rank, 티어 등 정보 호출

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		// 나중에 카운트 20으로 바꾸기

		int endNum = 9;
		List<String> grbc = null;
		grbc = aae.getMatchList(region, temp.getPuuid(),endNum);//매치리스트 호출
		/////////////// 여기 문제///////////////////
		AllGameData gd = aae.getMatchInfo(grbc, region, endNum, temp);//매치별 데이터 추출 및 가공
		List<GradeInfo> top3cham = aae.getTop3chamList(gd.cg);//top3챔피언 산출
		List<Positions> positionN = aae.getPositionN(gd.positions, gd.rankGames);//포지션 별 게이지 산출
		gd.mg = aae.getMgInfo(gd.mg, gd.mainKills, gd.mainAsis, gd.mainDeaths, gd.utotalkills, gd.totalkills);//mg데이터 재가공 - 유저 전체 평점 및 승률 등
		GameInfo gg = new GameInfo(gd.mg, gd.endNum); // 게임 기본 정보 넘기기
		session.setAttribute("nextNum", gd.endNum + 1);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		log.info("===================통과선=====================");

		model.addAttribute("gameInfo", gg);
		model.addAttribute("positions", positionN);
		model.addAttribute("summoner", temp);
		model.addAttribute("top3cham", top3cham);
		model.addAttribute("liv", LoginInfoVo);
		model.addAttribute("L_Api", gd.xx);
		model.addAttribute("profile_img",
				"http://ddragon.leagueoflegends.com/cdn/13.18.1/img/profileicon/" + temp.getProfileIconId() + ".png");

	}

}
