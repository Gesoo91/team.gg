package com.teamproject.spring.teamgg.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.teamproject.spring.teamgg.vo.BoardVO;

public interface BoardMapper {
	
	public List<BoardVO> bestList();
	
//	FreeBoard
	public List<BoardVO> freeList(int page);
	public int getTotalCountFree();
	public BoardVO freeRead(long f_idx);
	public void freeDel(long f_idx);
	public void freeWrite(BoardVO vo);
	public void freeModify(BoardVO vo);
	void updateViewCountFree(Long f_idx);
	public int getVoteCountFree(int f_idx);
	public void upVoteCountFree(Long f_idx);
	public void downVoteCountFree(Long f_idx);
    public int checkVoteFree(@Param("m_id") String m_id, @Param("f_idx") Long f_idx);
    public void updateVoteFree(@Param("m_id") String m_id, @Param("f_idx") Long f_idx);
    public void cancelVoteFree(@Param("m_id") String m_id, @Param("f_idx") Long f_idx);
    public List<BoardVO> searchPosts(int page, Map<String, Object> params);
	
//	TipBoard
	public List<BoardVO> tipList(int page);
	public int getTotalCountTip();
	public BoardVO tipRead(long t_idx);
	public void tipDel(long t_idx);
	public void tipWrite(BoardVO vo);
	public void tipModify(BoardVO vo);
	void updateViewCountTip(Long t_idx);
	public int getVoteCountTip(int t_idx);
	public void upVoteCountTip(Long t_idx);
	public void downVoteCountTip(Long t_idx);
    public int checkVoteTip(@Param("m_id") String m_id, @Param("t_idx") Long t_idx);
    public void updateVoteTip(@Param("m_id") String m_id, @Param("t_idx") Long t_idx);
    public void cancelVoteTip(@Param("m_id") String m_id, @Param("t_idx") Long t_idx);
	
//	CompBoard
	public List<BoardVO> compList(int page);
	public int getTotalCountComp();
	public BoardVO compRead(long c_idx);
	public void compDel(long c_idx);
	public void compWrite(BoardVO vo);
	public void compModify(BoardVO vo);
	void updateViewCountComp(Long c_idx);
	public int getVoteCountComp(int c_idx);
	public void upVoteCountComp(Long c_idx);
	public void downVoteCountComp(Long c_idx);
    public int checkVoteComp(@Param("m_id") String m_id, @Param("c_idx") Long c_idx);
    public void updateVoteComp(@Param("m_id") String m_id, @Param("c_idx") Long c_idx);
    public void cancelVoteComp(@Param("m_id") String m_id, @Param("c_idx") Long c_idx);
}
